import os
import sys
import subprocess
import tkinter as tk
from tkinter import ttk, messagebox

def run_model(model_choice):
    """Run OpenManus with the selected model"""
    if model_choice == "DeepSeek Coder":
        cmd = "python main.py deepseek"
    elif model_choice == "DeepSeek R1 (Free)":
        cmd = "python main.py deepseek_r1"
    elif model_choice == "Gemini Flash":
        cmd = "python main.py gemini"
    elif model_choice == "Gemini Flash (Free)":
        cmd = "python main.py gemini_free"
    elif model_choice == "Claude 3 Opus":
        cmd = "python main.py claude"
    elif model_choice == "Claude 3.5 Sonnet (Free)":
        cmd = "python main.py claude_free"
    else:
        messagebox.showerror("Error", "Please select a model")
        return
    
    # Close the UI window
    root.destroy()
    
    # Run the command
    os.system(cmd)

# Create the main window
root = tk.Tk()
root.title("OpenManus Launcher")
root.geometry("500x450")  # Increased height to accommodate new options
root.resizable(False, False)

# Set the window icon (using default icons)
try:
    root.iconbitmap(default='')
except:
    pass  # If icon setting fails, continue without an icon

# Add a header
header_frame = ttk.Frame(root)
header_frame.pack(fill="x", padx=20, pady=10)

header_label = ttk.Label(
    header_frame, 
    text="OpenManus AI Agent", 
    font=("Arial", 16, "bold")
)
header_label.pack()

description = ttk.Label(
    header_frame,
    text="Select the AI model you want to use:",
    font=("Arial", 10)
)
description.pack(pady=5)

# Create the main content area
content_frame = ttk.Frame(root)
content_frame.pack(fill="both", expand=True, padx=20, pady=10)

# Create a style for the model buttons
style = ttk.Style()
style.configure("Model.TButton", font=("Arial", 11), padding=10)

# Model selection section
model_frame = ttk.LabelFrame(content_frame, text="Available Models")
model_frame.pack(fill="both", expand=True, padx=10, pady=10)

# Model selection variable
selected_model = tk.StringVar()

# DeepSeek model options
deepseek_frame = ttk.Frame(model_frame)
deepseek_frame.pack(fill="x", padx=10, pady=5)

deepseek_rb = ttk.Radiobutton(
    deepseek_frame,
    text="DeepSeek Coder",
    value="DeepSeek Coder",
    variable=selected_model
)
deepseek_rb.pack(side="left", padx=5)

deepseek_label = ttk.Label(
    deepseek_frame,
    text="(Best for coding tasks)",
    font=("Arial", 8, "italic")
)
deepseek_label.pack(side="left")

# DeepSeek R1 (free) option
deepseek_free_frame = ttk.Frame(model_frame)
deepseek_free_frame.pack(fill="x", padx=10, pady=5)

deepseek_free_rb = ttk.Radiobutton(
    deepseek_free_frame,
    text="DeepSeek R1 (Free)",
    value="DeepSeek R1 (Free)",
    variable=selected_model
)
deepseek_free_rb.pack(side="left", padx=5)

deepseek_free_label = ttk.Label(
    deepseek_free_frame,
    text="(Free model, good for general tasks)",
    font=("Arial", 8, "italic")
)
deepseek_free_label.pack(side="left")

# Gemini model options
gemini_frame = ttk.Frame(model_frame)
gemini_frame.pack(fill="x", padx=10, pady=5)

gemini_rb = ttk.Radiobutton(
    gemini_frame,
    text="Gemini Flash",
    value="Gemini Flash",
    variable=selected_model
)
gemini_rb.pack(side="left", padx=5)

gemini_label = ttk.Label(
    gemini_frame,
    text="(Google's fast model)",
    font=("Arial", 8, "italic")
)
gemini_label.pack(side="left")

# Gemini free option
gemini_free_frame = ttk.Frame(model_frame)
gemini_free_frame.pack(fill="x", padx=10, pady=5)

gemini_free_rb = ttk.Radiobutton(
    gemini_free_frame,
    text="Gemini Flash (Free)",
    value="Gemini Flash (Free)",
    variable=selected_model
)
gemini_free_rb.pack(side="left", padx=5)

gemini_free_label = ttk.Label(
    gemini_free_frame,
    text="(Free experimental model from Google)",
    font=("Arial", 8, "italic")
)
gemini_free_label.pack(side="left")

# Claude model options
claude_frame = ttk.Frame(model_frame)
claude_frame.pack(fill="x", padx=10, pady=5)

claude_rb = ttk.Radiobutton(
    claude_frame,
    text="Claude 3 Opus",
    value="Claude 3 Opus",
    variable=selected_model
)
claude_rb.pack(side="left", padx=5)

claude_label = ttk.Label(
    claude_frame,
    text="(Best tool support, most capable)",
    font=("Arial", 8, "italic")
)
claude_label.pack(side="left")

# Claude free option
claude_free_frame = ttk.Frame(model_frame)
claude_free_frame.pack(fill="x", padx=10, pady=5)

claude_free_rb = ttk.Radiobutton(
    claude_free_frame,
    text="Claude 3.5 Sonnet (Free)",
    value="Claude 3.5 Sonnet (Free)",
    variable=selected_model
)
claude_free_rb.pack(side="left", padx=5)

claude_free_label = ttk.Label(
    claude_free_frame,
    text="(Free model with good tool support)",
    font=("Arial", 8, "italic")
)
claude_free_label.pack(side="left")

# Set default selected model
selected_model.set("Claude 3.5 Sonnet (Free)")  # Changed default to Claude Free

# Add a start button
button_frame = ttk.Frame(root)
button_frame.pack(fill="x", padx=20, pady=20)

start_button = ttk.Button(
    button_frame,
    text="Start OpenManus",
    style="Model.TButton",
    command=lambda: run_model(selected_model.get())
)
start_button.pack(side="right", padx=5)

exit_button = ttk.Button(
    button_frame,
    text="Exit",
    style="Model.TButton",
    command=root.destroy
)
exit_button.pack(side="right", padx=5)

# Add a footer with version info
footer_frame = ttk.Frame(root)
footer_frame.pack(fill="x", padx=20, pady=5)

footer_label = ttk.Label(
    footer_frame,
    text="OpenManus with OpenRouter Integration",
    font=("Arial", 8),
    foreground="gray"
)
footer_label.pack(side="right")

# Start the UI
root.mainloop() 