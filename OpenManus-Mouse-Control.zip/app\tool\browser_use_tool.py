import asyncio
import json
from typing import Optional
import re
import traceback
import os
import sys

from browser_use import Browser as BrowserUseBrowser
from browser_use import BrowserConfig
from browser_use.browser.context import BrowserContext, BrowserContextConfig
from browser_use.dom.service import DomService
from pydantic import Field, field_validator
from pydantic_core.core_schema import ValidationInfo

from app.config import config
from app.tool.base import BaseTool, ToolResult
from app.utils import logger


MAX_LENGTH = 2000

_BROWSER_DESCRIPTION = """
Interact with a web browser to perform various actions such as navigation, element interaction,
content extraction, and tab management. Supported actions include:
- 'navigate': Go to a specific URL
- 'click': Click an element by index
- 'input_text': Input text into an element
- 'screenshot': Capture a screenshot
- 'get_html': Get page HTML content
- 'get_text': Get text content of the page
- 'read_links': Get all links on the page
- 'execute_js': Execute JavaScript code
- 'scroll': Scroll the page
- 'switch_tab': Switch to a specific tab
- 'new_tab': Open a new tab
- 'close_tab': Close the current tab
- 'refresh': Refresh the current page
"""


class BrowserUseTool(BaseTool):
    name: str = "browser_use"
    description: str = _BROWSER_DESCRIPTION
    parameters: dict = {
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": [
                    "navigate",
                    "click",
                    "input_text",
                    "screenshot",
                    "get_html",
                    "get_text",
                    "execute_js",
                    "scroll",
                    "switch_tab",
                    "new_tab",
                    "close_tab",
                    "refresh",
                ],
                "description": "The browser action to perform",
            },
            "url": {
                "type": "string",
                "description": "URL for 'navigate' or 'new_tab' actions",
            },
            "index": {
                "type": "integer",
                "description": "Element index for 'click' or 'input_text' actions",
            },
            "text": {"type": "string", "description": "Text for 'input_text' action"},
            "script": {
                "type": "string",
                "description": "JavaScript code for 'execute_js' action",
            },
            "scroll_amount": {
                "type": "integer",
                "description": "Pixels to scroll (positive for down, negative for up) for 'scroll' action",
            },
            "tab_id": {
                "type": "integer",
                "description": "Tab ID for 'switch_tab' action",
            },
            "instruction": {
                "type": "string", 
                "description": "A clear instruction for what to do with the browser"
            },
        },
        "required": ["action"],
        "dependencies": {
            "navigate": ["url"],
            "click": ["index"],
            "input_text": ["index", "text"],
            "execute_js": ["script"],
            "switch_tab": ["tab_id"],
            "new_tab": ["url"],
            "scroll": ["scroll_amount"],
        },
    }

    lock: asyncio.Lock = Field(default_factory=asyncio.Lock)
    browser: Optional[BrowserUseBrowser] = Field(default=None, exclude=True)
    context: Optional[BrowserContext] = Field(default=None, exclude=True)
    dom_service: Optional[DomService] = Field(default=None, exclude=True)

    @field_validator("parameters", mode="before")
    def validate_parameters(cls, v: dict, info: ValidationInfo) -> dict:
        if not v:
            raise ValueError("Parameters cannot be empty")
        return v

    async def _ensure_browser_initialized(self) -> BrowserContext:
        """Ensure browser and context are initialized."""
        if self.browser is None:
            try:
                # Kesinlikle görünür bir tarayıcı istiyoruz
                browser_config_kwargs = {
                    "headless": False,
                    "disable_security": True,
                    "extra_chromium_args": ["--disable-web-security", "--allow-running-insecure-content"]
                }

                logger.info("Tarayıcı başlatılıyor... (headless: False)")

                # Eğer browser_config yapılandırması varsa, onları kullan
                if config.browser_config:
                    from browser_use.browser.browser import ProxySettings

                    # handle proxy settings.
                    if config.browser_config.proxy and config.browser_config.proxy.server:
                        browser_config_kwargs["proxy"] = ProxySettings(
                            server=config.browser_config.proxy.server,
                            username=config.browser_config.proxy.username,
                            password=config.browser_config.proxy.password,
                        )

                    browser_attrs = [
                        "disable_security",
                        "extra_chromium_args",
                        "chrome_instance_path",
                        "wss_url",
                        "cdp_url",
                    ]

                    for attr in browser_attrs:
                        value = getattr(config.browser_config, attr, None)
                        if value is not None:
                            if not isinstance(value, list) or value:
                                browser_config_kwargs[attr] = value
                
                # Chrome tarayıcı yolunu belirleme girişimi
                if sys.platform == "win32":
                    possible_paths = [
                        "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
                        "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
                        os.path.expanduser("~") + "\\AppData\\Local\\Google\\Chrome\\Application\\chrome.exe",
                    ]
                    
                    for path in possible_paths:
                        if os.path.exists(path):
                            browser_config_kwargs["chrome_instance_path"] = path
                            logger.info(f"Chrome bulundu: {path}")
                            break

                logger.info(f"Tarayıcı yapılandırması: {browser_config_kwargs}")
                self.browser = BrowserUseBrowser(BrowserConfig(**browser_config_kwargs))
                logger.info("Tarayıcı başlatıldı!")
            except Exception as e:
                logger.error(f"Tarayıcı başlatılırken hata oluştu: {e}")
                logger.error(traceback.format_exc())
                raise

        if self.context is None:
            try:
                context_config = BrowserContextConfig()

                # if there is context config in the config, use it.
                if (
                    config.browser_config
                    and hasattr(config.browser_config, "new_context_config")
                    and config.browser_config.new_context_config
                ):
                    context_config = config.browser_config.new_context_config

                self.context = await self.browser.new_context(context_config)
                self.dom_service = DomService(await self.context.get_current_page())
                logger.info("Tarayıcı bağlamı başlatıldı!")
            except Exception as e:
                logger.error(f"Tarayıcı bağlamı oluşturulurken hata oluştu: {e}")
                logger.error(traceback.format_exc())
                raise

        return self.context

    async def execute(self, **kwargs) -> str:
        """
        Instructs the browser to perform actions and returns the result.
        
        Args:
            **kwargs: Various arguments including:
                - action: The browser action to perform (navigate, click, etc.)
                - url: URL to navigate to
                - instruction: A clear instruction for what to do with the browser
                - Other parameters based on the action
                
        Returns:
            str: Result of the browser operation
        """
        try:
            # Log the browser use request
            logger.info(f"Browser use requested with parameters: {kwargs}")
            
            # Initialize browser if needed
            async with self.lock:
                context = await self._ensure_browser_initialized()
            
            # Get action and instruction
            action = kwargs.get('action')
            instruction = kwargs.get('instruction', '')
            
            # If we have a URL, extract it from parameters or from instruction
            url = kwargs.get('url')
            if not url and instruction and ("http" in instruction):
                # Simple URL extraction - find strings that look like URLs
                url_match = re.search(r'https?://[^\s<>"\']+|www\.[^\s<>"\']+', instruction)
                if url_match:
                    url = url_match.group(0)
                    if not url.startswith('http'):
                        url = 'https://' + url
                    logger.info(f"Extracted URL from instruction: {url}")
            
            # Process based on action
            result = ""
            if action == "navigate" and url:
                try:
                    logger.info(f"Navigating to URL: {url}")
                    await context.navigate_to(url)
                    await context.wait_for_load_state("networkidle", timeout=30000)
                    page_title = await context.get_title()
                    result = f"Successfully navigated to {url}. Page title: {page_title}"
                    logger.info(result)
                except Exception as e:
                    error_msg = f"Error navigating to {url}: {e}"
                    logger.error(error_msg)
                    return error_msg
                    
            elif action == "get_text":
                try:
                    text = await context.get_page_text()
                    result = f"Page text content:\n\n{text[:MAX_LENGTH]}"
                    if len(text) > MAX_LENGTH:
                        result += "\n... (content truncated due to length)"
                except Exception as e:
                    error_msg = f"Error getting page text: {e}"
                    logger.error(error_msg)
                    return error_msg
                    
            elif action == "get_html":
                try:
                    html = await context.get_page_html()
                    result = f"Page HTML content:\n\n{html[:MAX_LENGTH]}"
                    if len(html) > MAX_LENGTH:
                        result += "\n... (content truncated due to length)"
                except Exception as e:
                    error_msg = f"Error getting page HTML: {e}"
                    logger.error(error_msg)
                    return error_msg
                    
            elif action == "click" and 'index' in kwargs:
                try:
                    index = kwargs.get('index')
                    logger.info(f"Clicking element at index {index}")
                    await context.click_element_by_index(index)
                    result = f"Successfully clicked element at index {index}"
                except Exception as e:
                    error_msg = f"Error clicking element at index {kwargs.get('index')}: {e}"
                    logger.error(error_msg)
                    return error_msg
                    
            elif action == "execute_js" and 'script' in kwargs:
                try:
                    script = kwargs.get('script')
                    logger.info(f"Executing JavaScript: {script[:100]}...")
                    js_result = await context.execute_javascript(script)
                    result = f"JavaScript execution result: {js_result}"
                except Exception as e:
                    error_msg = f"Error executing JavaScript: {e}"
                    logger.error(error_msg)
                    return error_msg
            
            elif action == "input_text" and 'index' in kwargs and 'text' in kwargs:
                try:
                    index = kwargs.get('index')
                    text = kwargs.get('text')
                    logger.info(f"Inputting text into element at index {index}")
                    await context.input_text_by_index(index, text)
                    result = f"Successfully input text into element at index {index}"
                except Exception as e:
                    error_msg = f"Error inputting text: {e}"
                    logger.error(error_msg)
                    return error_msg
                    
            elif action == "screenshot":
                try:
                    logger.info("Taking screenshot")
                    screenshot = await context.take_screenshot()
                    result = "Screenshot taken successfully. (Binary data not displayed)"
                except Exception as e:
                    error_msg = f"Error taking screenshot: {e}"
                    logger.error(error_msg)
                    return error_msg
                    
            elif action == "scroll" and 'scroll_amount' in kwargs:
                try:
                    amount = kwargs.get('scroll_amount')
                    logger.info(f"Scrolling page by {amount} pixels")
                    await context.scroll(amount)
                    result = f"Successfully scrolled page by {amount} pixels"
                except Exception as e:
                    error_msg = f"Error scrolling: {e}"
                    logger.error(error_msg)
                    return error_msg
                    
            # If no specific action was processed or there's an instruction, try to use it
            if not result and instruction:
                try:
                    logger.info(f"Executing instruction: {instruction}")
                    js_result = await context.execute_javascript(f"""
                        (function() {{
                            try {{
                                // First try to summarize the page
                                const title = document.title;
                                const heading = document.querySelector('h1')?.textContent || 'No main heading';
                                const links = Array.from(document.querySelectorAll('a')).slice(0, 10)
                                    .map(a => {{ return {{ text: a.textContent.trim(), href: a.href }} }});
                                const paragraphs = Array.from(document.querySelectorAll('p')).slice(0, 5)
                                    .map(p => p.textContent.trim());
                                
                                return JSON.stringify({{
                                    title,
                                    heading,
                                    links,
                                    paragraphs,
                                    instruction: '{instruction}'
                                }});
                            }} catch (e) {{
                                return "Error executing JS: " + e.toString();
                            }}
                        }})();
                    """)
                    
                    try:
                        # Try to parse as JSON
                        parsed = json.loads(js_result)
                        result = f"""
Page Information:
- Title: {parsed.get('title', 'N/A')}
- Main Heading: {parsed.get('heading', 'N/A')}

First few paragraphs:
{chr(10).join(['- ' + p for p in parsed.get('paragraphs', ['No paragraphs found'])])}

Links on the page:
{chr(10).join(['- ' + link.get('text', 'No text') + ' (' + link.get('href', 'No URL') + ')' for link in parsed.get('links', [])])}
                        """
                    except:
                        result = f"JavaScript execution result: {js_result}"
                except Exception as e:
                    error_msg = f"Error processing instruction: {e}"
                    logger.error(error_msg)
                    return error_msg
            
            # Format the result nicely
            formatted_result = f"---\n\n**Browser Result:**\n\n{result}\n\n---\n\n"
            logger.info(f"Browser operation completed successfully")
            return formatted_result
        
        except Exception as e:
            logger.error(f"Error in BrowserUseTool.execute: {e}")
            logger.error(traceback.format_exc())
            # Attempt to cleanup
            await self.cleanup()
            return f"Error using the browser: {str(e)}"

    async def get_current_state(self) -> ToolResult:
        """Get the current browser state as a ToolResult."""
        async with self.lock:
            try:
                context = await self._ensure_browser_initialized()
                state = await context.get_state()
                state_info = {
                    "url": state.url,
                    "title": state.title,
                    "tabs": [tab.model_dump() for tab in state.tabs],
                    "interactive_elements": state.element_tree.clickable_elements_to_string(),
                }
                return ToolResult(output=json.dumps(state_info))
            except Exception as e:
                return ToolResult(error=f"Failed to get browser state: {str(e)}")

    async def cleanup(self):
        """Clean up browser resources."""
        async with self.lock:
            if self.context is not None:
                try:
                    await self.context.close()
                except Exception as e:
                    logger.error(f"Error closing browser context: {e}")
                self.context = None
            if self.browser is not None:
                try:
                    await self.browser.close()
                except Exception as e:
                    logger.error(f"Error closing browser: {e}")
                self.browser = None

    def __del__(self):
        """Clean up resources when the object is garbage collected."""
        try:
            asyncio.create_task(self.cleanup())
        except:
            pass
