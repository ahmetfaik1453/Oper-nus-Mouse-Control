import asyncio
from playwright.async_api import async_playwright
import time

async def test_mouse_control():
    print("Starting direct Playwright mouse control test...")
    
    async with async_playwright() as p:
        # Launch a new browser
        browser = await p.chromium.launch(headless=False)
        print("Browser launched")
        
        # Create a new context
        context = await browser.new_context()
        print("Browser context created")
        
        # Create a new page
        page = await context.new_page()
        print("New page created")
        
        # Navigate to Google
        print("Navigating to Google...")
        await page.goto("https://www.google.com")
        print("Navigated to Google")
        
        # Wait for the page to load
        await page.wait_for_load_state("networkidle")
        
        # Print the page title for debugging
        title = await page.title()
        print(f"Page title: {title}")
        
        # Try different selectors for the search box
        selectors = [
            'input[name="q"]',
            'input[type="text"]',
            'input.gLFyf',  # Common Google search class
            'textarea[name="q"]',  # Sometimes Google uses textarea
            'textarea',
            'input',
        ]
        
        search_box = None
        for selector in selectors:
            print(f"Trying to find search box with selector: {selector}")
            element = await page.query_selector(selector)
            if element:
                search_box = element
                print(f"Found search box with selector: {selector}")
                break
        
        if search_box:
            print("Found search box, clicking it...")
            await search_box.click()
            
            # Type some text
            search_text = "mouse control test"
            print(f"Typing: {search_text}")
            await search_box.fill(search_text)
            
            # Press Enter to search
            await page.keyboard.press("Enter")
            print("Pressed Enter")
            
            # Wait for search results
            await page.wait_for_load_state("networkidle")
            print("Search results loaded")
            
            # Scroll down
            print("Scrolling down")
            await page.mouse.wheel(0, 300)
            
            # Wait a bit
            await asyncio.sleep(2)
            
            # Take a screenshot
            screenshot_path = "direct_mouse_test_screenshot.png"
            await page.screenshot(path=screenshot_path)
            print(f"Screenshot saved to {screenshot_path}")
            
            # Wait for user to see the results
            print("Test completed successfully! Press Enter to close the browser...")
            input()
        else:
            print("Could not find search box with any selector")
            
            # Take a screenshot anyway to see what's on the page
            screenshot_path = "failed_test_screenshot.png"
            await page.screenshot(path=screenshot_path)
            print(f"Screenshot saved to {screenshot_path}")
            
            # Print page content for debugging
            content = await page.content()
            print("Page content (first 500 chars):")
            print(content[:500])
            
            # Wait for user to see the page
            print("Press Enter to close the browser...")
            input()
        
        # Close browser
        await context.close()
        await browser.close()
        print("Browser closed")

if __name__ == "__main__":
    asyncio.run(test_mouse_control()) 