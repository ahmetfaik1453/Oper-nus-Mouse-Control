import asyncio
from typing import List, Optional
import urllib.parse
import requests
from bs4 import BeautifulSoup
import traceback
import webbrowser
import os

from googlesearch import search

from app.tool.base import BaseTool
from app.utils import logger


class GoogleSearch(BaseTool):
    name: str = "google_search"
    description: str = """Perform a Google search and return a list of relevant links.
Use this tool when you need to find information on the web, get up-to-date data, or research specific topics.
The tool returns a list of URLs that match the search query and can optionally open results in a browser.
"""
    parameters: dict = {
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "(required) The search query to submit to Google.",
            },
            "num_results": {
                "type": "integer",
                "description": "(optional) The number of search results to return. Default is 5.",
                "default": 5,
            },
            "open_browser": {
                "type": "boolean",
                "description": "(optional) Whether to open the search results in a web browser. Default is True.",
                "default": True,
            },
            "open_result": {
                "type": "integer",
                "description": "(optional) Index of the result to open in browser (1-based). Default is None (not open any).",
            }
        },
        "required": ["query"],
    }

    _cached_results = {}

    async def execute(self, **kwargs) -> str:
        """
        Execute a search query and return the results as a formatted string.
        Otomatik olarak tarayıcıda açar.
        """
        try:
            query = kwargs.get("query", "")
            num_results = min(kwargs.get("num_results", 5), 10)  # Limit to 10 results maximum
            open_browser = kwargs.get("open_browser", True)  # Varsayılan olarak tarayıcıda aç
            open_result = kwargs.get("open_result", None)  # Specific result to open (1-based index)

            if not query:
                return "Error: No search query provided."

            # Log that we're performing a search
            logger.info(f"Performing Google search for: {query}")
            
            search_results = []
            
            # Check if we have cached results
            if query in self._cached_results:
                search_results = self._cached_results[query]
                logger.info(f"Using cached results for query: {query}")
            else:
                try:
                    # First try with the googlesearch package
                    logger.info("Using googlesearch-python package")
                    
                    for j, url in enumerate(search(query, num_results=num_results, lang="tr", stop=num_results, pause=2.0)):
                        if j >= num_results:
                            break
                            
                        # Try to get the title and description by visiting the URL
                        try:
                            headers = {
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36'
                            }
                            response = requests.get(url, headers=headers, timeout=5)
                            
                            if response.status_code == 200:
                                soup = BeautifulSoup(response.text, 'html.parser')
                                title = soup.title.string if soup.title else "No title found"
                                
                                # Extract a snippet from the content
                                paragraphs = soup.find_all('p')
                                snippet = ""
                                for p in paragraphs[:3]:  # Look at first few paragraphs
                                    text = p.get_text().strip()
                                    if len(text) > 50:  # Only consider substantial paragraphs
                                        snippet = text[:150] + ("..." if len(text) > 150 else "")
                                        break
                                
                                if not snippet and paragraphs:
                                    snippet = paragraphs[0].get_text().strip()[:150]
                                
                                if not snippet:
                                    snippet = "No description available"
                                    
                                search_results.append({
                                    "title": title,
                                    "link": url,
                                    "snippet": snippet
                                })
                            else:
                                search_results.append({
                                    "title": url,
                                    "link": url,
                                    "snippet": f"Could not access this page (Status code: {response.status_code})"
                                })
                                
                        except Exception as e:
                            logger.error(f"Error fetching URL {url}: {e}")
                            search_results.append({
                                "title": url,
                                "link": url,
                                "snippet": "No description available"
                            })
                    
                except Exception as search_pkg_error:
                    logger.error(f"Error using googlesearch package: {search_pkg_error}")
                    # If googlesearch package fails, continue to the backup method
                
                # If we didn't get results from googlesearch, use backup method
                if not search_results:
                    logger.info("Using direct HTTP request to Google")
                    search_url = f"https://www.google.com/search?q={urllib.parse.quote_plus(query)}&hl=tr&num={num_results}"
                    
                    headers = {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36',
                        'Accept-Language': 'tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
                        'Referer': 'https://www.google.com/',
                        'DNT': '1',
                        'Connection': 'keep-alive',
                        'Upgrade-Insecure-Requests': '1'
                    }
                    
                    # Log that we're making a request
                    logger.info(f"Making request to: {search_url}")
                    
                    # Make the request
                    response = requests.get(search_url, headers=headers)
                    
                    # Check if the request was successful
                    if response.status_code != 200:
                        return f"Error: Failed to retrieve search results. Status code: {response.status_code}"
                        
                    # Parse the HTML content with BeautifulSoup
                    soup = BeautifulSoup(response.text, 'html.parser')
                    
                    # Extract search results using various selectors
                    possible_selectors = [
                        'div.g', '.rc', 'div[data-hveid]', '#search div.g', 'div.tF2Cxc', 'div.yuRUbf'
                    ]
                    
                    result_divs = []
                    for selector in possible_selectors:
                        result_divs = soup.select(selector)
                        if result_divs:
                            logger.info(f"Found results with selector: {selector}")
                            break
                            
                    if not result_divs:
                        # Fallback to getting any links
                        all_links = soup.find_all('a')
                        for link in all_links:
                            href = link.get('href', '')
                            if href.startswith('/url?q=') and 'google.com' not in href:
                                actual_url = href.split('/url?q=')[1].split('&')[0]
                                actual_url = urllib.parse.unquote(actual_url)
                                
                                title = link.text.strip() if link.text else actual_url
                                
                                if not any(result.get('link') == actual_url for result in search_results) and 'google.' not in actual_url:
                                    search_results.append({
                                        "title": title if title else "Başlık bulunamadı",
                                        "link": actual_url,
                                        "snippet": "Açıklama mevcut değil"
                                    })
                                
                                if len(search_results) >= num_results:
                                    break
                    
                    else:
                        # Extract information from each search result
                        for i, div in enumerate(result_divs[:num_results]):
                            try:
                                link = None
                                title = None
                                snippet = None
                                
                                # Find title and link
                                title_element = div.find('h3')
                                if title_element:
                                    title = title_element.text.strip()
                                
                                link_element = div.find('a')
                                if link_element:
                                    link = link_element.get('href', '')
                                    
                                    # Handle Google's redirect URLs
                                    if link.startswith('/url?'):
                                        link = link.split('q=')[1].split('&')[0]
                                        link = urllib.parse.unquote(link)
                                
                                # Try different ways to find the snippet
                                snippet_selectors = [
                                    'div.VwiC3b', 'div.s3v9rd', 'span.st', 'div.IsZvec', 'div.cmlZRd'
                                ]
                                
                                for selector in snippet_selectors:
                                    snippet_element = div.select_one(selector)
                                    if snippet_element:
                                        snippet = snippet_element.text.strip()
                                        break
                                
                                # Only add valid results (must have a link at minimum)
                                if link and 'google.' not in link:
                                    search_results.append({
                                        "title": title if title else "Başlık bulunamadı",
                                        "link": link,
                                        "snippet": snippet if snippet else "Açıklama mevcut değil"
                                    })
                                    
                            except Exception as e:
                                logger.error(f"Error extracting search result {i}: {e}")
                                continue
                
                # Cache results for future use
                if search_results:
                    self._cached_results[query] = search_results
            
            # If no results were found, return a message
            if not search_results:
                return f"No search results found for query: {query}. Please try a different search term."
            
            # Handle opening results in browser if requested
            browser_message = ""
            if open_browser or open_result is not None:
                try:
                    # Try to use BrowserUseTool if available in the same context
                    from app.tool.browser_use_tool import BrowserUseTool
                    browser_tool = BrowserUseTool()
                    
                    if open_result is not None and 1 <= open_result <= len(search_results):
                        # Open specific result
                        result_to_open = search_results[open_result - 1]
                        url_to_open = result_to_open["link"]
                        
                        logger.info(f"Opening result {open_result} in browser: {url_to_open}")
                        browser_message = f"\n\nSonuç #{open_result} tarayıcıda açılıyor: {url_to_open}"
                        
                        # Bu kısmı değiştirdim - doğrudan tarayıcıda açıyoruz
                        webbrowser.open(url_to_open)
                        
                    elif open_browser:
                        # Open Google search results page
                        search_url = f"https://www.google.com/search?q={urllib.parse.quote_plus(query)}"
                        logger.info(f"Opening search results in browser: {search_url}")
                        browser_message = f"\n\nArama sonuçları tarayıcıda açılıyor: {search_url}"
                        
                        # Bu kısmı değiştirdim - doğrudan tarayıcıda açıyoruz
                        webbrowser.open(search_url)
                
                except ImportError:
                    # Fall back to using the system's default browser if BrowserUseTool isn't available
                    logger.info("BrowserUseTool not available, using system default browser")
                    try:
                        if open_result is not None and 1 <= open_result <= len(search_results):
                            url_to_open = search_results[open_result - 1]["link"]
                            logger.info(f"Opening result {open_result} in default browser: {url_to_open}")
                            browser_message = f"\n\nSonuç #{open_result} tarayıcıda açılıyor: {url_to_open}"
                            webbrowser.open(url_to_open)
                        elif open_browser:
                            search_url = f"https://www.google.com/search?q={urllib.parse.quote_plus(query)}"
                            logger.info(f"Opening search results in default browser: {search_url}")
                            browser_message = f"\n\nArama sonuçları tarayıcıda açılıyor: {search_url}"
                            webbrowser.open(search_url)
                    except Exception as e:
                        logger.error(f"Error opening browser: {e}")
                        browser_message = f"\n\nTarayıcı açılırken hata oluştu: {str(e)}"
                
                except Exception as e:
                    logger.error(f"Error using BrowserUseTool: {e}")
                    browser_message = f"\n\nTarayıcı açılırken hata oluştu: {str(e)}"
            
            # Format the results (daha kısa bir format)
            formatted_results = "**Google Arama Sonuçları:**\n\n"
            for i, result in enumerate(search_results[:num_results], 1):
                formatted_results += f"{i}. **{result['title']}**\n"
                formatted_results += f"   {result['link']}\n"
                formatted_results += f"   {result['snippet'][:100]+'...' if len(result['snippet'])>100 else result['snippet']}\n\n"
            
            # Add browser message if any
            if browser_message:
                formatted_results += browser_message
            
            return formatted_results
            
        except Exception as e:
            logger.error(f"Error in GoogleSearch.execute: {e}")
            logger.error(traceback.format_exc())
            return f"Arama yaparken hata oluştu: {str(e)}"
