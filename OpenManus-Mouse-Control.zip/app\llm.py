from typing import Dict, List, Optional, Union

from openai import (
    APIError,
    AsyncAzureOpenAI,
    AsyncOpenAI,
    AuthenticationError,
    OpenAIError,
    RateLimitError,
)
from tenacity import retry, stop_after_attempt, wait_random_exponential

from app.config import LLMSettings, config
from app.logger import logger  # Assuming a logger is set up in your app
from app.schema import Message, TOOL_CHOICE_TYPE, ROLE_VALUES, TOOL_CHOICE_VALUES, ToolChoice


class LLM:
    _instances: Dict[str, "LLM"] = {}

    def __new__(
        cls, config_name: str = "default", llm_config: Optional[LLMSettings] = None
    ):
        if config_name not in cls._instances:
            instance = super().__new__(cls)
            instance.__init__(config_name, llm_config)
            cls._instances[config_name] = instance
        return cls._instances[config_name]

    def __init__(
        self, config_name: str = "default", llm_config: Optional[LLMSettings] = None
    ):
        if not hasattr(self, "client"):  # Only initialize if not already initialized
            llm_config = llm_config or config.llm
            llm_config = llm_config.get(config_name, llm_config["default"])
            self.model = llm_config.model
            self.max_tokens = llm_config.max_tokens
            self.temperature = llm_config.temperature
            self.api_type = llm_config.api_type
            self.api_key = llm_config.api_key
            self.api_version = llm_config.api_version
            self.base_url = llm_config.base_url
            
            # Check if using OpenRouter
            self.is_openrouter = "openrouter.ai" in self.base_url
            
            # Define default headers
            default_headers = {}
            
            # Add OpenRouter specific headers if using OpenRouter
            if self.is_openrouter:
                default_headers = {
                    "HTTP-Referer": "https://openmanus.github.io",
                    "X-Title": "OpenManus"
                }
                logger.info(f"Using OpenRouter with model: {self.model}")
            
            if self.api_type == "azure":
                self.client = AsyncAzureOpenAI(
                    base_url=self.base_url,
                    api_key=self.api_key,
                    api_version=self.api_version,
                    default_headers=default_headers
                )
            else:
                self.client = AsyncOpenAI(
                    api_key=self.api_key, 
                    base_url=self.base_url, 
                    default_headers=default_headers
                )

    @staticmethod
    def format_messages(messages: List[Union[dict, Message]]) -> List[dict]:
        """
        Format messages for LLM by converting them to OpenAI message format.

        Args:
            messages: List of messages that can be either dict or Message objects

        Returns:
            List[dict]: List of formatted messages in OpenAI format

        Raises:
            ValueError: If messages are invalid or missing required fields
            TypeError: If unsupported message types are provided

        Examples:
            >>> msgs = [
            ...     Message.system_message("You are a helpful assistant"),
            ...     {"role": "user", "content": "Hello"},
            ...     Message.user_message("How are you?")
            ... ]
            >>> formatted = LLM.format_messages(msgs)
        """
        formatted_messages = []

        for message in messages:
            if isinstance(message, dict):
                # If message is already a dict, ensure it has required fields
                if "role" not in message:
                    raise ValueError("Message dict must contain 'role' field")
                formatted_messages.append(message)
            elif isinstance(message, Message):
                # If message is a Message object, convert it to dict
                formatted_messages.append(message.to_dict())
            else:
                raise TypeError(f"Unsupported message type: {type(message)}")

        # Validate all messages have required fields
        for msg in formatted_messages:
            if msg["role"] not in ROLE_VALUES:
                raise ValueError(f"Invalid role: {msg['role']}")
            if "content" not in msg and "tool_calls" not in msg:
                raise ValueError(
                    "Message must contain either 'content' or 'tool_calls'"
                )

        return formatted_messages

    @retry(
        wait=wait_random_exponential(min=1, max=60),
        stop=stop_after_attempt(6),
    )
    async def ask(
        self,
        messages: List[Union[dict, Message]],
        system_msgs: Optional[List[Union[dict, Message]]] = None,
        stream: bool = True,
        temperature: Optional[float] = None,
    ) -> str:
        """
        Send a prompt to the LLM and get the response.

        Args:
            messages: List of conversation messages
            system_msgs: Optional system messages to prepend
            stream (bool): Whether to stream the response
            temperature (float): Sampling temperature for the response

        Returns:
            str: The generated response

        Raises:
            ValueError: If messages are invalid or response is empty
            OpenAIError: If API call fails after retries
            Exception: For unexpected errors
        """
        try:
            # Format system and user messages
            if system_msgs:
                system_msgs = self.format_messages(system_msgs)
                messages = system_msgs + self.format_messages(messages)
            else:
                messages = self.format_messages(messages)

            if not stream:
                # Non-streaming request
                response = await self.client.chat.completions.create(
                    model=self.model,
                    messages=messages,
                    max_tokens=self.max_tokens,
                    temperature=temperature or self.temperature,
                    stream=False,
                )
                if not response.choices or not response.choices[0].message.content:
                    raise ValueError("Empty or invalid response from LLM")
                return response.choices[0].message.content

            # Streaming request
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                max_tokens=self.max_tokens,
                temperature=temperature or self.temperature,
                stream=True,
            )

            collected_messages = []
            async for chunk in response:
                chunk_message = chunk.choices[0].delta.content or ""
                collected_messages.append(chunk_message)
                print(chunk_message, end="", flush=True)

            print()  # Newline after streaming
            full_response = "".join(collected_messages).strip()
            if not full_response:
                raise ValueError("Empty response from streaming LLM")
            return full_response

        except ValueError as ve:
            logger.error(f"Validation error: {ve}")
            raise
        except OpenAIError as oe:
            logger.error(f"OpenAI API error: {oe}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error in ask: {e}")
            raise

    def tool_format_for_model(self, tool, model_name):
        """Format tools for different model types with better compatibility"""
        if "gemini" in model_name.lower():
            # Gemini için daha basit tool format
            if tool.get("type") == "function":
                func = tool.get("function", {})
                name = func.get("name", "")
                desc = func.get("description", "")
                params = func.get("parameters", {})
                
                # Gemini için basit format:
                return {
                    "name": name,
                    "description": desc, 
                    "parameters": params
                }
        # Diğer modeller için normal format
        return tool

    @retry(
        wait=wait_random_exponential(min=1, max=60),
        stop=stop_after_attempt(6),
    )
    async def ask_tool(
        self,
        messages: List[Union[dict, Message]],
        system_msgs: Optional[List[Union[dict, Message]]] = None,
        timeout: int = 300,
        tools: Optional[List[dict]] = None,
        tool_choice: TOOL_CHOICE_TYPE = ToolChoice.AUTO, # type: ignore
        temperature: Optional[float] = None,
        **kwargs,
    ):
        """
        Ask LLM using functions/tools and return the response.

        Args:
            messages: List of conversation messages
            system_msgs: Optional system messages to prepend
            timeout: Request timeout in seconds
            tools: List of tools to use
            tool_choice: Tool choice strategy
            temperature: Sampling temperature for the response
            **kwargs: Additional completion arguments

        Returns:
            ChatCompletionMessage: The model's response

        Raises:
            ValueError: If tools, tool_choice, or messages are invalid
            OpenAIError: If API call fails after retries
            Exception: For unexpected errors
        """
        try:
            # Validate tool_choice
            if tool_choice not in TOOL_CHOICE_VALUES:
                raise ValueError(f"Invalid tool_choice: {tool_choice}")

            # Format messages
            if system_msgs:
                system_msgs = self.format_messages(system_msgs)
                messages = system_msgs + self.format_messages(messages)
            else:
                messages = self.format_messages(messages)

            # Validate tools if provided
            if tools:
                for tool in tools:
                    if not isinstance(tool, dict) or "type" not in tool:
                        raise ValueError("Each tool must be a dict with 'type' field")

            # For OpenRouter, we need special handling
            use_tools = True
            use_tool_choice = tool_choice
            
            if self.is_openrouter:
                logger.info(f"Using OpenRouter for model: {self.model}")
                
                # If using DeepSeek or Gemini through OpenRouter, they might not support tool calls well
                if "deepseek" in self.model or "gemini" in self.model:
                    logger.warning(f"Model {self.model} might have limited tool calling support via OpenRouter")
                    
                    # For these models, we'll include special instructions in the messages
                    if tools and len(tools) > 0:
                        # Convert tools to text description and add to the prompt
                        tool_descriptions = []
                        for tool in tools:
                            if tool.get("type") == "function":
                                func_info = tool.get("function", {})
                                name = func_info.get("name", "unknown")
                                description = func_info.get("description", "No description")
                                parameters = func_info.get("parameters", {})
                                
                                tool_desc = f"Tool: {name}\nDescription: {description}\nParameters: {str(parameters)}"
                                tool_descriptions.append(tool_desc)
                        
                        if tool_descriptions:
                            tools_text = "\n\n".join(tool_descriptions)
                            tool_instruction = {"role": "system", "content": f"You have the following tools available:\n\n{tools_text}\n\nUse tools by responding with: 'I'll use the [tool_name] tool with these parameters: [parameters]'"}
                            messages.insert(0, tool_instruction)
                    
                    # Don't send tool parameters for OpenRouter models that don't fully support them
                    # to avoid 400 errors
                    use_tools = False
                    use_tool_choice = None

            # Set up the completion request
            completion_args = {
                "model": self.model,
                "messages": messages,
                "temperature": temperature or self.temperature,
                "max_tokens": self.max_tokens,
                "timeout": timeout,
                **kwargs,
            }
            
            # Only add tools and tool_choice if we're using them
            if use_tools and tools:
                completion_args["tools"] = tools
                completion_args["tool_choice"] = use_tool_choice

            # Execute the API call
            response = await self.client.chat.completions.create(**completion_args)

            # Check if response is valid
            if not response.choices or not response.choices[0].message:
                print(response)
                raise ValueError("Invalid or empty response from LLM")

            # If we're using OpenRouter with a model that doesn't support tools,
            # and the response includes "I'll use the [tool_name] tool",
            # parse it manually and create a tool_call response
            message = response.choices[0].message
            if not use_tools and tools and message.content:
                content = message.content
                tool_use_match = None
                
                # Look for tool use patterns - both "I'll use" and "I will use" formats and more flexible matching
                import re
                # Pattern for json formatted parameters or more flexible text
                tool_pattern1 = r"I(?:'ll| will) use the (\w+) tool with (?:these )?parameters:?\s*(\{.+?\}|\S.*?)(?=$|\n\n)"
                # Pattern for "key: value" format parameters 
                tool_pattern2 = r"I(?:'ll| will) use the (\w+) tool with (?:these )?parameters:?\s*([^{}].*?)(?=$|\n\n)"
                # Pattern for plain language descriptions (especially for Gemini)
                tool_pattern3 = r"I need to (?:search|find|look up|google|use google|query)(?: for| about)? ['\"]?(.+?)['\"]?"
                
                # Try first pattern with JSON or flexible formatting
                tool_matches = re.search(tool_pattern1, content, re.DOTALL | re.IGNORECASE)
                
                if tool_matches:
                    tool_name = tool_matches.group(1)
                    params_text = tool_matches.group(2)
                    
                    # Try to parse parameters as JSON or text
                    try:
                        import json
                        # Clean up the text to make it valid JSON
                        params_text = params_text.strip()
                        if params_text.startswith("{") and params_text.endswith("}"):
                            params = json.loads(params_text)
                        else:
                            # If not valid JSON, use as parameters based on context
                            if tool_name == "google_search":
                                params = {"query": params_text}
                            else:
                                params = {"text": params_text}
                            
                        # Create a synthetic tool call
                        from openai.types.chat import ChatCompletionMessage
                        from openai.types.chat.chat_completion_message import FunctionCall
                        from openai.types.chat.chat_completion_message_tool_call import ChatCompletionMessageToolCall
                        
                        tool_calls = [
                            ChatCompletionMessageToolCall(
                                id=f"call_{tool_name}",
                                type="function",
                                function=FunctionCall(
                                    name=tool_name,
                                    arguments=json.dumps(params)
                                )
                            )
                        ]
                        
                        # Create a new message with the tool call
                        synthetic_message = ChatCompletionMessage(
                            content=None,
                            role="assistant",
                            tool_calls=tool_calls
                        )
                        
                        return synthetic_message
                    except Exception as e:
                        logger.error(f"Error parsing synthetic tool call: {e}")
                        # Fall back to regular message handling
                
                # Try second pattern - key-value text params
                tool_matches = re.search(tool_pattern2, content, re.DOTALL | re.IGNORECASE)
                if tool_matches:
                    tool_name = tool_matches.group(1)
                    params_text = tool_matches.group(2).strip()
                    
                    try:
                        # Try to convert key:value pairs to JSON
                        param_dict = {}
                        
                        # Simple parsing for "key: value" pairs
                        param_pairs = re.findall(r'(\w+):\s*([^,\n]+)(?:,|\n|$)', params_text)
                        for key, value in param_pairs:
                            param_dict[key.strip()] = value.strip().strip('"\'')
                        
                        if not param_dict:
                            # Fallback to simple text if parsing fails
                            param_dict = {"query": params_text}
                            
                        # Create a synthetic tool call
                        from openai.types.chat import ChatCompletionMessage
                        from openai.types.chat.chat_completion_message import FunctionCall
                        from openai.types.chat.chat_completion_message_tool_call import ChatCompletionMessageToolCall
                        
                        tool_calls = [
                            ChatCompletionMessageToolCall(
                                id=f"call_{tool_name}",
                                type="function",
                                function=FunctionCall(
                                    name=tool_name,
                                    arguments=json.dumps(param_dict)
                                )
                            )
                        ]
                        
                        # Create a new message with the tool call
                        synthetic_message = ChatCompletionMessage(
                            content=None,
                            role="assistant",
                            tool_calls=tool_calls
                        )
                        
                        return synthetic_message
                    except Exception as e:
                        logger.error(f"Error parsing text params for tool call: {e}")
                
                # Special pattern for search queries (for Gemini especially)
                search_match = re.search(tool_pattern3, content, re.DOTALL | re.IGNORECASE)
                if search_match and "google_search" in [t.get("function", {}).get("name") for t in tools if t.get("type") == "function"]:
                    search_query = search_match.group(1).strip().strip('"\'')
                    try:
                        # Create a synthetic google_search tool call
                        from openai.types.chat import ChatCompletionMessage
                        from openai.types.chat.chat_completion_message import FunctionCall
                        from openai.types.chat.chat_completion_message_tool_call import ChatCompletionMessageToolCall
                        
                        tool_calls = [
                            ChatCompletionMessageToolCall(
                                id="call_google_search",
                                type="function",
                                function=FunctionCall(
                                    name="google_search",
                                    arguments=json.dumps({"query": search_query})
                                )
                            )
                        ]
                        
                        # Create a new message with the tool call
                        synthetic_message = ChatCompletionMessage(
                            content=None,
                            role="assistant",
                            tool_calls=tool_calls
                        )
                        
                        return synthetic_message
                    except Exception as e:
                        logger.error(f"Error creating search tool call: {e}")
                
                # No valid tool calls detected, return original message
                return message

            return message

        except ValueError as ve:
            logger.error(f"Validation error in ask_tool: {ve}")
            raise
        except OpenAIError as oe:
            if isinstance(oe, AuthenticationError):
                logger.error("Authentication failed. Check API key.")
            elif isinstance(oe, RateLimitError):
                logger.error("Rate limit exceeded. Consider increasing retry attempts.")
            elif isinstance(oe, APIError):
                logger.error(f"API error: {oe}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error in ask_tool: {e}")
            raise
