import asyncio
import os
import sys

from browser_use import Browser as BrowserUseBrowser
from browser_use import BrowserConfig
from browser_use.browser.context import BrowserContext, BrowserContextConfig

async def test_browser():
    print("Starting browser test...")
    
    # Configure browser
    browser_config_kwargs = {
        "headless": False,
        "disable_security": True,
        "extra_chromium_args": ["--disable-web-security", "--allow-running-insecure-content", "--enable-automation"]
    }
    
    # Find Chrome on Windows
    if sys.platform == "win32":
        possible_paths = [
            "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
            "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
            os.path.expanduser("~") + "\\AppData\\Local\\Google\\Chrome\\Application\\chrome.exe",
        ]
        
        for path in possible_paths:
            if os.path.exists(path):
                browser_config_kwargs["chrome_instance_path"] = path
                print(f"Chrome found: {path}")
                break
    
    print(f"Browser configuration: {browser_config_kwargs}")
    
    try:
        # Initialize browser
        browser = BrowserUseBrowser(BrowserConfig(**browser_config_kwargs))
        print("Browser initialized!")
        
        # Create context
        context = await browser.new_context(BrowserContextConfig())
        print("Browser context initialized!")
        
        # Navigate to a website
        await context.navigate_to("https://www.google.com")
        print("Navigated to Google")
        
        # Wait a bit to see the browser
        await asyncio.sleep(5)
        
        # Get page title
        title = await context.get_title()
        print(f"Page title: {title}")
        
        # Test clicking
        await context.click_element_by_index(0)  # Click the first clickable element
        print("Clicked first element")
        
        # Wait a bit more to see the result
        await asyncio.sleep(3)
        
        # Take a screenshot
        screenshot = await context.take_screenshot()
        print("Screenshot taken")
        
        # Scroll down
        await context.scroll(300)
        print("Scrolled down 300px")
        
        # Wait a bit more to see the scroll effect
        await asyncio.sleep(3)
        
        # Close browser
        await context.close()
        await browser.close()
        print("Browser closed")
        
        print("Browser test completed successfully!")
        
    except Exception as e:
        print(f"Error during browser test: {e}")
        import traceback
        print(traceback.format_exc())

if __name__ == "__main__":
    asyncio.run(test_browser()) 