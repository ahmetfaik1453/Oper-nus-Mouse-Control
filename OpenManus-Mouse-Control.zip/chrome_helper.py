import os
import sys
import subprocess
import time
import socket
import signal
import psutil

def is_port_in_use(port):
    """Check if a port is in use."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(('localhost', port)) == 0

def kill_processes_by_name(name):
    """Kill all processes matching the given name."""
    for proc in psutil.process_iter(['pid', 'name']):
        # Check if process name contains the given name string
        if name.lower() in proc.info['name'].lower():
            try:
                process = psutil.Process(proc.info['pid'])
                process.terminate()
                print(f"Terminated process {proc.info['name']} (PID: {proc.info['pid']})")
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                print(f"Failed to terminate process {proc.info['name']} (PID: {proc.info['pid']})")

def start_chrome_with_debug_port(chrome_path, debug_port=9222):
    """Start Chrome with a remote debugging port."""
    # Kill any existing Chrome processes
    kill_processes_by_name("chrome")
    
    # Wait a bit for processes to terminate
    time.sleep(2)
    
    # Check if the port is still in use
    if is_port_in_use(debug_port):
        print(f"Port {debug_port} is still in use. Please manually close any applications using this port.")
        return False
    
    # Command to start Chrome with remote debugging
    cmd = [
        chrome_path,
        f"--remote-debugging-port={debug_port}",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-extensions",
        "--disable-component-extensions-with-background-pages",
        "--disable-background-networking",
        "--disable-background-timer-throttling",
        "--disable-backgrounding-occluded-windows",
        "--disable-breakpad",
        "--disable-client-side-phishing-detection",
        "--disable-default-apps",
        "--disable-dev-shm-usage",
        "--disable-sync",
        "--disable-features=Translate,BackForwardCache",
        "--disable-web-security",
        "--allow-running-insecure-content",
        "--enable-automation",
        "--no-sandbox",
        "--user-data-dir=./chrome-user-data"
    ]
    
    try:
        # Start Chrome as a subprocess
        print(f"Starting Chrome with debug port {debug_port}...")
        subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        
        # Wait a bit for Chrome to start
        time.sleep(3)
        
        # Check if the port is now in use, indicating Chrome has started successfully
        if is_port_in_use(debug_port):
            print(f"Chrome started successfully with debug port {debug_port}")
            return True
        else:
            print(f"Failed to start Chrome. Debug port {debug_port} is not in use.")
            return False
    except Exception as e:
        print(f"Error starting Chrome: {e}")
        return False

def find_chrome_path():
    """Find the path to the Chrome executable."""
    if sys.platform == "win32":
        possible_paths = [
            "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
            "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
            os.path.expanduser("~") + "\\AppData\\Local\\Google\\Chrome\\Application\\chrome.exe",
        ]
        
        for path in possible_paths:
            if os.path.exists(path):
                print(f"Chrome found: {path}")
                return path
    
    print("Chrome not found. Please specify the path to Chrome.")
    return None

if __name__ == "__main__":
    # Find Chrome path
    chrome_path = find_chrome_path()
    if chrome_path:
        # Start Chrome with debug port
        success = start_chrome_with_debug_port(chrome_path)
        if success:
            print("Chrome is now running with remote debugging enabled.")
            print("Press Ctrl+C to quit...")
            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                print("Shutting down Chrome...")
                kill_processes_by_name("chrome")
                print("Done.") 