import asyncio
import sys

from app.agent.manus import DeepSeekManus, GeminiManus, Manus
from app.llm import LLM
from app.logger import logger


class DeepSeekR1Manus(Manus):
    """A Manus agent that uses DeepSeek R1 as the LLM backend through OpenRouter."""
    
    name: str = "DeepSeekR1Manus"
    description: str = "A versatile agent powered by DeepSeek R1"
    
    def __init__(self):
        logger.info("Initializing DeepSeek R1 Manus agent")
        super().__init__(llm_model="deepseek_r1")


class GeminiFreeFlashManus(Manus):
    """A Manus agent that uses the free Gemini Flash as the LLM backend."""
    
    name: str = "GeminiFreeFlashManus"
    description: str = "A versatile agent powered by free Gemini Flash"
    
    def __init__(self):
        logger.info("Initializing Gemini Free Flash Manus agent")
        super().__init__(llm_model="gemini_free")


class GPTManus(Manus):
    """A Manus agent that uses OpenAI GPT as the LLM backend through OpenRouter."""
    
    name: str = "GPTManus"
    description: str = "A versatile agent powered by OpenAI GPT with better tool support"
    
    def __init__(self):
        logger.info("Initializing GPT Manus agent")
        super().__init__(llm_model="gpt")


class ClaudeManus(Manus):
    """A Manus agent that uses Claude as the LLM backend through OpenRouter."""
    
    name: str = "ClaudeManus"
    description: str = "A versatile agent powered by Claude 3 Opus with better tool support"
    
    def __init__(self):
        logger.info("Initializing Claude Manus agent")
        super().__init__(llm_model="claude")


class ClaudeFreeManus(Manus):
    """A Manus agent that uses Claude free version as the LLM backend through OpenRouter."""
    
    name: str = "ClaudeFreeManus"
    description: str = "A versatile agent powered by free Claude 3.5 Sonnet with better tool support"
    
    def __init__(self):
        logger.info("Initializing Claude Free Manus agent")
        super().__init__(llm_model="claude_free")


async def main():
    # Default to DeepSeekManus
    agent_type = "deepseek"
    
    # Check command line arguments for agent type
    if len(sys.argv) > 1:
        arg = sys.argv[1].lower()
        if arg in ["deepseek", "gemini", "deepseek_r1", "gemini_free", "claude", "claude_free", "gpt"]:
            agent_type = arg
        else:
            logger.warning(f"Unknown agent type: {arg}. Using DeepSeek as default.")
    
    # Create the appropriate agent based on the agent type
    if agent_type == "gemini":
        logger.info("Using Google Gemini Flash 2.0 agent")
        agent = GeminiManus()
    elif agent_type == "deepseek_r1":
        logger.info("Using DeepSeek R1 free agent")
        agent = DeepSeekR1Manus()
    elif agent_type == "gemini_free":
        logger.info("Using Gemini Flash free agent")
        agent = GeminiFreeFlashManus()
    elif agent_type == "claude":
        logger.info("Using Claude 3 Opus agent")
        agent = ClaudeManus()
    elif agent_type == "claude_free":
        logger.info("Using Claude 3.5 Sonnet free agent")
        agent = ClaudeFreeManus()
    elif agent_type == "gpt":
        logger.info("Using OpenAI GPT agent")
        agent = GPTManus()
    else:  # default to deepseek
        logger.info("Using DeepSeek Coder agent")
        agent = DeepSeekManus()
        
    try:
        prompt = input("Enter your prompt: ")
        if not prompt.strip():
            logger.warning("Empty prompt provided.")
            return

        logger.warning("Processing your request...")
        await agent.run(prompt)
        logger.info("Request processing completed.")
    except KeyboardInterrupt:
        logger.warning("Operation interrupted.")


if __name__ == "__main__":
    asyncio.run(main())
