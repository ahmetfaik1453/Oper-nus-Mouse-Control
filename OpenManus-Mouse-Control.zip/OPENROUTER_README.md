# OpenManus with OpenRouter

This version of OpenManus has been configured to work with OpenRouter, specifically with:

1. **DeepSeek Coder** - A powerful coding model from DeepSeek AI
2. **Google Gemini Flash** - Google's fast Gemini model for general tasks

## Model Configuration

The models have been set up with the following API key and model IDs:

- **API Key**: `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`

- **Model IDs**:
  - DeepSeek Coder: `deepseek/deepseek-coder`
  - DeepSeek R1 (Free): `deepseek/deepseek-r1-distill-llama-70b:free`
  - Gemini Flash: `google/gemini-2.0-flash-001`
  - Gemini Flash (Free): `google/gemini-2.0-flash-exp:free`

## Running OpenManus

### Using the Launcher

The easiest way to run OpenManus is using the launcher:

1. Double-click the `Start-OpenManus.bat` file
2. Select your preferred model from the GUI
3. Click "Start OpenManus"

### Using the Batch Files

You can also run OpenManus directly using the batch files:

```
OpenManus-DeepSeek.bat
OpenManus-Gemini.bat
```

### Manual Command Line

If you prefer to run from the command line:

```
python main.py deepseek        # For DeepSeek Coder
python main.py deepseek_r1     # For DeepSeek R1 (Free)
python main.py gemini          # For Gemini Flash
python main.py gemini_free     # For Gemini Flash (Free)
```

## About Tool Calling Support

OpenRouter models might have limited support for tool calling compared to native OpenAI models. This version of OpenManus includes a special text-based fallback mechanism to handle tool calls with models that don't fully support OpenAI's tool calling interface.

This fallback works by:

1. Converting tool definitions to text instructions
2. Parsing the model's text response for tool usage patterns
3. Converting text responses back into a tool call format that OpenManus can understand

## Troubleshooting

If you encounter issues:

1. **Model ID Errors**: If OpenRouter's model IDs change, you'll need to update these in `config/config.toml`.

2. **API Key Issues**: If your OpenRouter key expires, you'll need to obtain a new one and update it in the config file.

3. **Tool Calling Issues**: If you experience problems with tool calls, the fallback mechanism should handle it automatically. However, complex tools might not work perfectly.

4. **Response Quality**: The quality of responses will vary between models. DeepSeek Coder is better for programming tasks, while Gemini Flash may be better for general tasks.

## Customizing the Configuration

You can modify the configuration by editing `config/config.toml`. The important settings are:

- `model`: The model ID for OpenRouter
- `api_key`: Your OpenRouter API key
- `temperature`: Controls randomness (0.0-1.0)
- `max_tokens`: Maximum output length 