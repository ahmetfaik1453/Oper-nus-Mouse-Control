import asyncio
import os
import sys
import time

from browser_use import Browser as BrowserUseBrowser
from browser_use import BrowserConfig
from browser_use.browser.context import BrowserContext, BrowserContextConfig

async def test_mouse_control():
    print("Starting mouse control test...")
    
    # Configure browser
    browser_config_kwargs = {
        "headless": False,
        "disable_security": True,
        "extra_chromium_args": ["--disable-web-security", "--allow-running-insecure-content", "--enable-automation"]
    }
    
    # Find Chrome on Windows
    if sys.platform == "win32":
        possible_paths = [
            "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
            "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
            os.path.expanduser("~") + "\\AppData\\Local\\Google\\Chrome\\Application\\chrome.exe",
        ]
        
        for path in possible_paths:
            if os.path.exists(path):
                browser_config_kwargs["chrome_instance_path"] = path
                print(f"Chrome found: {path}")
                break
    
    print(f"Browser configuration: {browser_config_kwargs}")
    
    try:
        # Initialize browser
        browser = BrowserUseBrowser(BrowserConfig(**browser_config_kwargs))
        print("Browser initialized!")
        
        # Create context
        context = await browser.new_context(BrowserContextConfig())
        print("Browser context initialized!")
        
        # Navigate to a website with interactive elements
        await context.navigate_to("https://www.google.com")
        print("Navigated to Google")
        
        # Wait a bit for the page to load
        await asyncio.sleep(2)
        
        # Get the state of the page to see clickable elements
        state = await context.get_state()
        print("Clickable elements:")
        print(state.element_tree.clickable_elements_to_string())
        
        # Click on the search box (index may vary, usually around 0-5)
        search_box_index = 4  # This index might need adjustment based on Google's current layout
        print(f"Clicking element at index {search_box_index}")
        await context.click_element_by_index(search_box_index)
        
        # Wait a bit
        await asyncio.sleep(1)
        
        # Type some text
        search_text = "mouse control test"
        print(f"Typing: {search_text}")
        await context.input_text_by_index(search_box_index, search_text)
        
        # Wait a bit
        await asyncio.sleep(1)
        
        # Press Enter to search
        await context.press_key("Enter")
        print("Pressed Enter")
        
        # Wait for search results
        await asyncio.sleep(3)
        
        # Scroll down
        print("Scrolling down")
        await context.scroll(300)
        
        # Wait a bit
        await asyncio.sleep(2)
        
        # Click on a search result (index will vary)
        result_index = 10  # This index might need adjustment
        print(f"Clicking on search result at index {result_index}")
        try:
            await context.click_element_by_index(result_index)
            print("Clicked on search result")
        except Exception as e:
            print(f"Error clicking search result: {e}. This is expected if the index is incorrect.")
            
        # Wait a bit to see the new page
        await asyncio.sleep(3)
        
        # Take a screenshot to capture the current state
        screenshot_path = "mouse_test_screenshot.png"
        await context.take_screenshot(path=screenshot_path)
        print(f"Screenshot saved to {screenshot_path}")
        
        # Close browser
        await context.close()
        await browser.close()
        print("Browser closed")
        
        print("Mouse control test completed!")
        
    except Exception as e:
        print(f"Error during mouse control test: {e}")
        import traceback
        print(traceback.format_exc())

if __name__ == "__main__":
    asyncio.run(test_mouse_control()) 