# PowerShell script to create a desktop shortcut for the OpenManus launcher

# Get desktop path
$desktopPath = [Environment]::GetFolderPath("Desktop")
$currentDir = (Get-Location).Path

# Create shortcut for the launcher
$launcherShortcut = "$desktopPath\OpenManus-Launcher.lnk"
$WshShell = New-Object -ComObject WScript.Shell
$shortcut = $WshShell.CreateShortcut($launcherShortcut)
$shortcut.TargetPath = "$currentDir\Start-OpenManus.bat"
$shortcut.WorkingDirectory = $currentDir
$shortcut.IconLocation = "shell32.dll,5"  # Use a nice icon from shell32.dll
$shortcut.Description = "OpenManus AI Agent Launcher"
$shortcut.Save()

Write-Host "Launcher shortcut created successfully on your desktop!" -ForegroundColor Green
Write-Host "You can now launch OpenManus directly from your desktop." -ForegroundColor Cyan 