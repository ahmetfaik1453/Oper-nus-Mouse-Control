# PowerShell script to create desktop shortcuts for OpenManus

# Get desktop path
$desktopPath = [Environment]::GetFolderPath("Desktop")
$currentDir = (Get-Location).Path

# Create shortcut for DeepSeek version
$deepseekShortcut = "$desktopPath\OpenManus-DeepSeek.lnk"
$WshShell = New-Object -ComObject WScript.Shell
$shortcut = $WshShell.CreateShortcut($deepseekShortcut)
$shortcut.TargetPath = "$currentDir\OpenManus-DeepSeek.bat"
$shortcut.WorkingDirectory = $currentDir
$shortcut.IconLocation = "shell32.dll,7"  # Use a nice icon from shell32.dll
$shortcut.Description = "OpenManus with DeepSeek AI Model"
$shortcut.Save()

# Create shortcut for Gemini version
$geminiShortcut = "$desktopPath\OpenManus-Gemini.lnk"
$shortcut = $WshShell.CreateShortcut($geminiShortcut)
$shortcut.TargetPath = "$currentDir\OpenManus-Gemini.bat"
$shortcut.WorkingDirectory = $currentDir
$shortcut.IconLocation = "shell32.dll,14"  # Use a different nice icon
$shortcut.Description = "OpenManus with Gemini Flash AI Model"
$shortcut.Save()

Write-Host "Desktop shortcuts created successfully!" -ForegroundColor Green
Write-Host "You can now launch OpenManus directly from your desktop." -ForegroundColor Cyan 