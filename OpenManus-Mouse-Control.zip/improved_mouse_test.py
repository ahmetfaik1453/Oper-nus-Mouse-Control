import asyncio
import os
import sys
import time

from browser_use import Browser as BrowserUseBrowser
from browser_use import BrowserConfig
from browser_use.browser.context import BrowserContext, BrowserContextConfig

from chrome_helper import find_chrome_path, start_chrome_with_debug_port, kill_processes_by_name

async def test_mouse_control():
    print("Starting improved mouse control test...")
    
    # Find Chrome path
    chrome_path = find_chrome_path()
    if not chrome_path:
        print("Chrome not found. Cannot continue.")
        return
    
    # Start Chrome with debug port
    debug_port = 9222
    success = start_chrome_with_debug_port(chrome_path, debug_port)
    if not success:
        print("Failed to start Chrome with debug port. Cannot continue.")
        return
    
    # Give Chrome a moment to fully initialize
    print("Waiting for Chrome to fully initialize...")
    await asyncio.sleep(5)
    
    # Configure browser
    browser_config_kwargs = {
        "headless": False,
        "disable_security": True,
        "extra_chromium_args": ["--disable-web-security", "--allow-running-insecure-content", "--enable-automation"],
        "cdp_url": f"http://localhost:{debug_port}"
    }
    
    print(f"Browser configuration: {browser_config_kwargs}")
    
    try:
        # Initialize browser
        browser = BrowserUseBrowser(BrowserConfig(**browser_config_kwargs))
        print("Browser initialized!")
        
        # Create context
        context = await browser.new_context(BrowserContextConfig())
        print("Browser context initialized!")
        
        # Navigate to a website with interactive elements
        print("Navigating to Google...")
        await context.navigate_to("https://www.google.com")
        print("Navigated to Google")
        
        # Wait a bit for the page to load
        await asyncio.sleep(2)
        
        # Get the state of the page to see clickable elements
        state = await context.get_state()
        print("Clickable elements:")
        clickable_elements = state.element_tree.clickable_elements_to_string()
        print(clickable_elements)
        
        # Find a good candidate for the search box
        search_box_index = None
        for i, line in enumerate(clickable_elements.split('\n')):
            if "search" in line.lower() or "input" in line.lower():
                search_box_index = i
                break
        
        if search_box_index is None:
            search_box_index = 4  # Fallback to a common index
        
        print(f"Clicking element at index {search_box_index}")
        await context.click_element_by_index(search_box_index)
        
        # Wait a bit
        await asyncio.sleep(1)
        
        # Type some text
        search_text = "mouse control test"
        print(f"Typing: {search_text}")
        await context.input_text_by_index(search_box_index, search_text)
        
        # Wait a bit
        await asyncio.sleep(1)
        
        # Press Enter to search
        await context.press_key("Enter")
        print("Pressed Enter")
        
        # Wait for search results
        await asyncio.sleep(3)
        
        # Scroll down
        print("Scrolling down")
        await context.scroll(300)
        
        # Wait a bit
        await asyncio.sleep(2)
        
        # Take a screenshot to capture the current state
        screenshot_path = "mouse_test_screenshot.png"
        await context.take_screenshot(path=screenshot_path)
        print(f"Screenshot saved to {screenshot_path}")
        
        # Wait for user to see the results
        print("Test completed successfully! Press Enter to close the browser...")
        input()
        
    except Exception as e:
        print(f"Error during mouse control test: {e}")
        import traceback
        print(traceback.format_exc())
    finally:
        try:
            # Close browser properly
            if 'context' in locals() and context:
                await context.close()
            if 'browser' in locals() and browser:
                await browser.close()
            print("Browser closed properly")
        except Exception as e:
            print(f"Error closing browser: {e}")
        
        # Make sure to kill Chrome processes
        kill_processes_by_name("chrome")
        print("Chrome processes terminated")

if __name__ == "__main__":
    asyncio.run(test_mouse_control()) 