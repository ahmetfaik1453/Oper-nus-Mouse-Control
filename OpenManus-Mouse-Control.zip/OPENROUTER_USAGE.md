# OpenManus with OpenRouter Usage Guide

This version of OpenManus has been configured to work with OpenRouter, allowing you to use DeepSeek Coder v2 and Google Gemini Flash 2.0 models.

## Available Models

1. **DeepSeek Coder v2** - A powerful code-focused model from DeepSeek AI
2. **Google Gemini Flash 2.0** - Google's latest fast Gemini model

## How to Run

### Basic Usage

To run OpenManus with DeepSeek (default):
```bash
python main.py
# or explicitly specify:
python main.py deepseek
# or use the batch file:
run_deepseek.bat
```

To run OpenManus with Gemini:
```bash
python main.py gemini
# or use the batch file:
run_gemini.bat
```

### Flow-based Version

For the more advanced flow-based version:

With DeepSeek:
```bash
python run_flow.py
# or explicitly specify:
python run_flow.py deepseek
# or use the batch file:
run_flow_deepseek.bat
```

With Gemini:
```bash
python run_flow.py gemini
# or use the batch file:
run_flow_gemini.bat
```

## Configuration

The system is configured to use the following API keys via OpenRouter:

1. DeepSeek Coder v2: `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`
2. Google Gemini Flash 2.0: `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`

If you need to change the API keys or models, you can edit the `config/config.toml` file.

## Using the Agent

After starting the agent, you will be prompted to enter your request. Type your query and press Enter. The agent will process your request and respond accordingly.

Here are some example prompts you can try:

1. "Write a simple weather app in Python"
2. "Create a simple calculator using HTML, CSS, and JavaScript"
3. "Search for the latest news about AI"
4. "Execute a Python script to analyze some data"

The agent has access to the following tools:
- Python code execution
- Web browsing
- Google search
- File operations

## Troubleshooting

If you encounter issues:

1. **API Key Issues**: Check if the API keys in `config/config.toml` are correct
2. **Module Errors**: Make sure all dependencies are installed with `pip install -r requirements.txt`
3. **Browser Issues**: Try running with `headless = true` in the browser config section
4. **Model Limitations**: Some features might be limited depending on the model you're using

For DeepSeek and Gemini models via OpenRouter, tool calling capabilities might be limited compared to native OpenAI models.

## Comparing Models

- **DeepSeek Coder**: Better for coding tasks and technical problem-solving
- **Gemini Flash**: Faster responses and potentially better for general knowledge tasks

Try both models to see which one works best for your specific use cases! 